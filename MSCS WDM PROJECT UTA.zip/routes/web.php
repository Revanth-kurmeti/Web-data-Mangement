<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\InstructorController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProgramCoordinatorController;
use App\Http\Controllers\QAController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::middleware('auth')->group(function () {
    $role = Auth()->user()->role ?? 'guest';
    Route::get("/dashboard", function () use ($role) {
        return redirect()->route($role . '.dashboard');
    })->name('dashboard');
});

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::middleware(['auth', 'checkrole:student'])->group(function () {
    Route::get('/student/dashboard', [StudentController::class, 'dashboard'])->name('student.dashboard');
    Route::get('/dashboard/courses', [StudentController::class, 'courses'])->name('student.courses');
    Route::get('/dashboard/courses/{course}', [StudentController::class, 'show'])->name('course.show');
});

Route::middleware(['auth', 'checkrole:admin'])->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::get('/admin/courses', [AdminController::class, 'courses'])->name('admin.courses');
    Route::get('/admin/permissions', [AdminController::class, 'permissions'])->name('admin.permissions');
    Route::get('/admin/profiles', [AdminController::class, 'profiles'])->name('admin.profiles');
});
Route::middleware(['auth', 'checkrole:instructor'])->group(function () {
    Route::get('/instructor/courses', [InstructorController::class, 'courses'])->name('instructor.courses');
    Route::get('instructor/performance', [InstructorController::class, 'performance'])->name('instructor.performance');
    Route::get('/instructor/dashboard', [InstructorController::class, 'dashboard'])->name('instructor.dashboard');
});

Route::middleware(['auth', 'checkrole:program_coordinator'])->group(function () {
    Route::get('/program_coordinator/dashboard', [ProgramCoordinatorController::class, 'dashboard'])->name('program_coordinator.dashboard');
    Route::get('/program_coordinator/performance', [ProgramCoordinatorController::class, 'performance'])->name('program_coordinator.performance');
});
/*
 *                     'Dashboard' => route('qa_officer.dashboard'),
                    'Policies' => route('qa_officer.policies'),
                    'Assessments' => route('qa_officer.assessments'),
 */
Route::middleware(['auth', 'checkrole:qa_officer'])->group(function () {
    Route::get('/qa_officer/dashboard', [QAController::class, 'dashboard'])->name('qa_officer.dashboard');
    Route::get('/qa_officer/policies', [QAController::class, 'policies'])->name('qa_officer.policies');
    Route::get('/qa_officer/assessments', [QAController::class, 'assessment'])->name('qa_officer.assessments');
});


Route::get('/help', function () {
    return view('help');
})->name('help');
Route::get('/unauthorized', function () {
    return view('unauthorized');
})->name('guest.dashboard');

Route::post('/chat', 'App\Http\Controllers\ChatController');

require __DIR__ . '/auth.php';
