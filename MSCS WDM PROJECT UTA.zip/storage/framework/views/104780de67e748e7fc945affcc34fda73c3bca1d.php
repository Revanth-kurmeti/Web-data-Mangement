<div>
    <?php if($courses->isEmpty()): ?>
        <p>You are not enrolled in any courses.</p>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <dialog id="my_modal_<?php echo e($course->id); ?>" class="modal">
                    <div class="modal-box">
                        <form method="dialog">
                            <button class="btn btn-sm ring ring-secondary ring-inset btn-circle btn-ghost absolute right-2 top-2">✕</button>
                        </form>
                        <h3 class="font-bold text-lg">Objectives</h3>
                        <section>
                            <?php if($course->objectives->isEmpty()): ?>
                                <p>There are no objectives for this course.</p>
                            <?php else: ?>
                                <table class="table table-auto w-full mt-2">
                                    <?php $__currentLoopData = $course->objectives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objective): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="font-semibold"><?php echo e($objective->objective_id); ?></td>
                                            <td><?php echo e($objective->description); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            <?php endif; ?>
                        </section>

                        <h3 class="font-bold text-lg">Exams</h3>
                        <section>
                            <?php if($course->exams->isEmpty()): ?>
                                <p>There are no exams for this course.</p>
                            <?php else: ?>
                                <table class="table table-auto w-full mt-2">
                                    <thead>
                                    <tr>
                                        <th class="font-semibold">Exam Id</th>
                                        <th class="font-semibold">Professor</th>
                                        <th class="font-semibold">Grade</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $course->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php

                                            $professor = App\Models\Instructor::where('id', $exam->professor_id)->first();
                                            $net_id = Auth::user()->net_id;
                                            $studentId = App\Models\Student::where('net_id', $net_id)->first()->id;

                                            $result = Illuminate\Support\Facades\DB::selectOne('SELECT grade FROM results WHERE exam_id = ? AND student_id = ?', [$exam->id, $studentId]);
                                        ?>
                                        <tr>
                                            <td class="font-semibold"><?php echo e($exam->exam_id); ?></td>
                                            <td><?php echo e($professor->name ?? 'N/A'); ?></td>
                                            <td><?php echo e($result->grade ?? 'Not Graded'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            <?php endif; ?>
                        </section>

                    </div>
                    <form method="dialog" class="modal-backdrop">
                        <button>close</button>
                    </form>
                </dialog>
                <div class="bg-white rounded-md shadow-sm overflow-hidden">
                    <div class="image">
                        <img class="object-cover w-full h-[150px]" height="50%" src="<?php echo e(asset('images/courseImage.jpg')); ?>" alt="Course Image" />
                    </div>

                    <div class="p-3 sm:p-4">
                        <h3 class="text-lg font-bold"><?php echo e($course->course_name); ?></h3>
                        <table class="table table-auto w-full mt-2">
                            <tr>
                                <td class="font-semibold">Course Id:</td>
                                <td><?php echo e($course->course_id); ?></td>
                            </tr>
                            <tr>
                                <td class="font-semibold">Section:</td>
                                <td><?php echo e($course->section); ?></td>
                            </tr>
                            <tr>
                                <td class="font-semibold">Mode:</td>
                                <td><?php echo e($course->mode); ?></td>
                            </tr>
                        </table>

                        <button class="btn btn-sm btn-secondary ring hover:btn-primary" onclick="my_modal_<?php echo e($course->id); ?>.showModal()">More Info</button>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\revan\Downloads\Laravel (2)\Laravel\resources\views/livewire/student-courses.blade.php ENDPATH**/ ?>