<div class="bg-secondary flex items-center justify-center">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer')->html();
} elseif ($_instance->childHasBeenRendered('vHiJyV2')) {
    $componentId = $_instance->getRenderedChildComponentId('vHiJyV2');
    $componentTag = $_instance->getRenderedChildComponentTagName('vHiJyV2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vHiJyV2');
} else {
    $response = \Livewire\Livewire::mount('footer');
    $html = $response->html();
    $_instance->logRenderedChild('vHiJyV2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>