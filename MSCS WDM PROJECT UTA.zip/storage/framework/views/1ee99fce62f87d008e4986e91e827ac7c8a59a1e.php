<div>
    <!-- Create Result Button -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ring-1 ring-offset-1','wire:click' => 'openCreateModal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ring-1 ring-offset-1','wire:click' => 'openCreateModal']); ?>Create Result <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <!-- Create Result Dialog -->
    <?php if($showCreateModal): ?>
        <dialog open class="modal">
            <div class="modal-box">
                <form wire:submit.prevent="store">
                    <label for="exam_id">Exam ID</label>
                    <select id="exam_id" class="input input-bordered" wire:model="exam_id">
                    <option value="option">select an exam</option>
                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($exam->id); ?>"><?php echo e($exam->exam_id); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['exam_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="student_id">Student ID</label>
                    <select id="student_id" class="input input-bordered" wire:model="student_id">
                    <option value="option1">select a student id</option>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($student->id); ?>"><?php echo e($student->student_id); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="grade">Grade</label>
                    <input class="input input-bordered" id="grade" type="text" wire:model="grade">
                    <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="action-buttons flex gap-2">
                        <button class="btn btn-sm ring-1 ring-offset-1 btn-primary"  type="submit">Create Result</button>
                        <button class="btn btn-sm ring-1 ring-offset-1 btn-secondary" type="button" wire:click="closeCreateModal">Close</button>
                    </div>
                </form>
            </div>
        </dialog>
    <?php endif; ?>

    <!-- Results Table -->
    <table class="table table-compact">
        <thead>
        <tr>
            <th>Result ID</th>
            <th>Exam ID</th>
            <th>Student ID</th>
            <th>Grade</th>
            <th>Actions</th>
        </tr>
        <tbody>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($result->$result_id); ?></td>
                <td><?php echo e($result->exam_id); ?></td>
                <td><?php echo e($result->student_id); ?></td>
                <td><?php echo e($result->grade); ?></td>
                <td class="flex gap-2">
                    <button class="btn ring-1 ring-offset-1 btn-sm btn-primary" wire:click="openEditModal(<?php echo e($result->id); ?>)">Edit</button>
                    <button class="btn ring-1 ring-offset-1 btn-sm btn-secondary" wire:click="delete(<?php echo e($result->id); ?>)">Delete</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Edit Result Dialog -->
<?php if($showEditModal): ?>
    <dialog open class="modal">
        <div class="modal-box">
            <form wire:submit.prevent="update">
                <label for="exam_id">Exam ID</label>
                <select id="exam_id" class="input input-bordered" wire:model="exam_id" disabled>
                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($exam->id); ?>"><?php echo e($exam->exam_id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['exam_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="student_id">Student ID</label>
                <select id="student_id" class="input input-bordered" wire:model="student_id" disabled>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($student->id); ?>"><?php echo e($student->student_id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="grade">Grade</label>
                <input class="input input-bordered" id="grade" type="text" wire:model="grade">
                <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="action-buttons flex gap-2">
                    <button class="btn btn-sm ring-1 ring-offset-1 btn-primary" type="submit">Update Result</button>
                    <button class="btn btn-sm ring-1 ring-offset-1 btn-secondary" type="button" wire:click="closeEditModal">Close</button>
                </div>
        </form>
        </div>
    </dialog>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\revan\Downloads\Laravel (2)\Laravel\resources\views/livewire/results-component.blade.php ENDPATH**/ ?>