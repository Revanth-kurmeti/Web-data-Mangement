<div>
    <?php if(!empty($courses)): ?>
        <h2>
            Manage Courses
            <button class="btn btn-sm btn-primary" wire:click="create">Create</button>
        </h2>

    <!--Validation Errors-->
        <?php if($errors->any()): ?>
            <div class="alert flex flex-col alert-danger">
                <div class="font-medium text-red-600">
                    <?php echo e(__('Whoops! Something went wrong.')); ?>

                </div>

                <ul class="mt-3 list-disc list-inside text-sm text-red-600">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>
        <?php endif; ?>
        <table class="table">
            <thead>
            <tr>
                <th>Course Name</th>
                <th>Course Id</th>
                <th>Section</th>
                <th>Mode</th>
                <th>Instructor Id</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($instructor = App\Models\Instructor::find($course->instructor_id)); ?>
                <tr>
                    <td><?php echo e($course->course_name); ?></td>
                    <td><?php echo e($course->course_id); ?></td>
                    <td><?php echo e($course->section); ?></td>
                    <td><?php echo e($course->mode); ?></td>
                    <td><?php echo e($instructor->name); ?></td>
                    <td>
                        <button class="btn btn-sm btn-outline ring-2 ring-secondary" wire:click="edit(<?php echo e($course->id); ?>)">
                            Edit
                        </button>


                        <!-- Create Course Modal -->
                        <dialog id="my_modal_create" class="modal">
                            <div class="modal-box">
                                <button
                                    class="btn btn-sm ring ring-inset ring-secondary btn-circle btn-ghost absolute right-2 top-2"
                                    onclick="closeModal('my_modal_create')">
                                    ✕
                                </button>

                                <script>
                                    function closeModal(modalId) {
                                        document.getElementById(modalId).close();
                                    }
                                </script>

                                <center class="text-xl">
                                    Create Course
                                </center>

                                <form class="flex flex-col" wire:submit.prevent="save">
                                    <label for="course_name">Course Name</label>
                                    <input id="course_name" class="rounded mt-2" wire:model.defer="course_name" type="text" placeholder="Course Name">
                                    <label for="course_id">Course ID</label>
                                    <input id="course_id" class="rounded mt-2" wire:model.defer="course_id" type="text" placeholder="Course ID">
                                    <label for="section">Section</label>
                                    <input id="section" class="rounded mt-2" wire:model.defer="section" type="text" placeholder="Section">
                                    <label for="mode">Mode</label>
                                    <input id="mode" class="rounded mt-2" wire:model.defer="mode" type="text" placeholder="Mode">
                                    <label for="instructor_id">Instructor ID</label>
                                    <input id="instructor_id" class="rounded mt-2" wire:model.defer="instructor_id" type="text" placeholder="Instructor ID">
                                    <button class="mt-3 btn btn-primary ring ring-secondary" type="submit">Save</button>
                                </form>


                            </div>
                        </dialog>

                        <!-- Edit Course Modal -->
                        <dialog id="my_modal_edit<?php echo e($course->id); ?>" class="modal">
                            <div class="modal-box">
                                <button
                                    class="btn btn-sm ring ring-inset ring-secondary btn-circle btn-ghost absolute right-2 top-2"
                                    onclick="closeModal('my_modal_edit<?php echo e($course->id); ?>')">
                                    ✕
                                </button>
                                <center class="text-xl">
                                    Edit Course <?php echo e($course->course_id); ?>

                                </center>
                                <form class="flex flex-col" wire:submit.prevent="save">
                                    <label for="course_name">Course Name</label>
                                    <input id="course_name" class="rounded mt-2" wire:model.defer="course_name" type="text" placeholder="Course Name">
                                    <label for="course_id">Course ID</label>
                                    <input id="course_id" class="rounded mt-2" wire:model.defer="course_id" type="text" placeholder="Course ID">
                                    <label for="section">Section</label>
                                    <input id="section" class="rounded mt-2" wire:model.defer="section" type="text" placeholder="Section">
                                    <label for="mode">Mode</label>
                                    <input id="mode" class="rounded mt-2" wire:model.defer="mode" type="text" placeholder="Mode">
                                    <label for="instructor_id">Instructor ID</label>
                                    <input id="instructor_id" class="rounded mt-2" wire:model.defer="instructor_id" type="text" placeholder="Instructor ID">
                                    <button class="mt-3 btn btn-primary ring ring-secondary" type="submit">Save</button>
                                </form>
                            </div>

                        </dialog>
                        <button class="btn btn-sm bg-red-600 btn-danger" wire:click="delete(<?php echo e($course->id); ?>)">Delete
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have no courses.</p>
    <?php endif; ?>

        <script>
            document.addEventListener('DOMContentLoaded', () => {
                window.addEventListener('openModal', event => {
                    const modalId = event.detail.id;
                    document.getElementById(modalId).showModal();
                });
                window.addEventListener('closeModal', event => {
                    const modalId = event.detail.id;
                    document.getElementById(modalId).close();
                    window.location.reload();
                });
                function closeModal(modalId) {
                    document.getElementById(modalId).close();
                }
            });
        </script>

</div>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/livewire/manage-courses.blade.php ENDPATH**/ ?>