<div class="text-5xl text-white font-bold">
    MSC
</div>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>