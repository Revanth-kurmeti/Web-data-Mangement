<div class="div">
    <h2 class="text-center text-2xl font-bold text-gray-700">
        Your Instructor Courses
    </h2>
    <?php if(!empty($courseList)): ?>
        <div class="grid grid-cols-1 gap-4 my-4 md:grid-cols-2 lg:grid-cols-3">
            <?php $__currentLoopData = $courseList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('livewire.course-card', ['course' => $course], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="text-center">
            <h1 class="text-2xl font-bold text-gray-700">No courses yet</h1>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/livewire/instructor-dash/course-list.blade.php ENDPATH**/ ?>