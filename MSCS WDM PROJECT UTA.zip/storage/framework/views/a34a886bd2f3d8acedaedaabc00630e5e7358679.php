<div>
    <table class="table-zebra table">
        <thead>
        <tr>
            <th>Course Name</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($course->course_name); ?></td>
                <td>
                    <button class="btn btn-sm ring-2 ring-secondary" wire:click="loadReviews(<?php echo e($course->id); ?>)">View Reviews</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
    <dialog id="reviewsModal" class="modal">
        <div class="modal-box flex flex-col gap-3 w-[900px]">
        <button class="btn btn-ghost absolute right-2 top-2 btn-circle ring ring-inset btn-sm" id="closeModal" onclick="closeModal('reviewsModal')
        function closeModal(id) {
            window.dispatchEvent(new CustomEvent('closeModal', { detail: { id: id } }))
        }
        ">✖</button>
        <?php if($reviews==null): ?>
            <h2>No Reviews</h2>
        <?php else: ?>
        <h2>Course Reviews</h2>
        <ul>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($review->message); ?> - <?php echo e($review->user->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
            <table class="table">
                <thead>
                <tr>
                    <th>Message</th>
                    <th>User</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($review->message); ?></td>
                        <td><?php echo e($review->user->name); ?></td>
                        <td>
                            <button class="btn btn-sm ring-2 ring-red-600 hover:bg-red-600 hover:text-white" wire:click="deleteReview(<?php echo e($review->id); ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <form class="flex flex-col gap-3" wire:submit.prevent="saveReview">
            <textarea class="textarea textarea-bordered" wire:model.defer="newReviewMessage"></textarea>
            <button class="btn ring ring-secondary btn-primary w-full" type="submit">Submit Review</button>
        </form>
        </div>
    </dialog>
    <script>
        window.addEventListener('openModal', event => {
            document.getElementById(event.detail.id).showModal();
        });
        window.addEventListener('closeModal', event => {
            document.getElementById(event.detail.id).close();
        });
    </script>
</div>



<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/livewire/course-reviews.blade.php ENDPATH**/ ?>