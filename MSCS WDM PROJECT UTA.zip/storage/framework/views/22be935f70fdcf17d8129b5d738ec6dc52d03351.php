<div class="text-5xl text-white font-bold">
    MSC
</div>
<?php /**PATH C:\Users\shano\Downloads\Laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>