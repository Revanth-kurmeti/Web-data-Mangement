<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Our Application</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome, <?php echo e($name); ?>!</h1>
        <p>Thank you for registering with us. We're delighted to have you on board.</p>
        <p>If you have any questions or need assistance, please do not hesitate to contact us.</p>
        
        <p>Best Regards,<br>Your Team</p>
    </div>
</body>
</html>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/emails/welcome.blade.php ENDPATH**/ ?>