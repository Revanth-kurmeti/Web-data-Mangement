<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('layouts.navbar', [
    'dropdownLinks' => [
        'Profile' => route('profile.edit'),
        'Help' => route('help'),
        'Profiles' => route('admin.profiles'),
        'Permissions' => route('admin.permissions'),
        'Dashboard' => route('admin.dashboard'),
        'Logout' => route('logout')
    ]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xs text-gray-800 leading-tight">
            Admin/Permissions
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="data">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage-permissions', [])->html();
} elseif ($_instance->childHasBeenRendered('UbeN9Gv')) {
    $componentId = $_instance->getRenderedChildComponentId('UbeN9Gv');
    $componentTag = $_instance->getRenderedChildComponentTagName('UbeN9Gv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UbeN9Gv');
} else {
    $response = \Livewire\Livewire::mount('manage-permissions', []);
    $html = $response->html();
    $_instance->logRenderedChild('UbeN9Gv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/admin/permissions.blade.php ENDPATH**/ ?>