<div class="bg-secondary flex items-center justify-center">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer')->html();
} elseif ($_instance->childHasBeenRendered('sWN7mvr')) {
    $componentId = $_instance->getRenderedChildComponentId('sWN7mvr');
    $componentTag = $_instance->getRenderedChildComponentTagName('sWN7mvr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sWN7mvr');
} else {
    $response = \Livewire\Livewire::mount('footer');
    $html = $response->html();
    $_instance->logRenderedChild('sWN7mvr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>