<div class="bg-secondary flex items-center justify-center">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer')->html();
} elseif ($_instance->childHasBeenRendered('Hh18NPL')) {
    $componentId = $_instance->getRenderedChildComponentId('Hh18NPL');
    $componentTag = $_instance->getRenderedChildComponentTagName('Hh18NPL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Hh18NPL');
} else {
    $response = \Livewire\Livewire::mount('footer');
    $html = $response->html();
    $_instance->logRenderedChild('Hh18NPL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\Users\shano\Downloads\Laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>