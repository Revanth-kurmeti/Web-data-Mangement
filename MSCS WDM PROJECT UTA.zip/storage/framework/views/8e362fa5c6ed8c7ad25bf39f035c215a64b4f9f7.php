<div class="bg-secondary flex items-center justify-center">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer')->html();
} elseif ($_instance->childHasBeenRendered('c8McyYF')) {
    $componentId = $_instance->getRenderedChildComponentId('c8McyYF');
    $componentTag = $_instance->getRenderedChildComponentTagName('c8McyYF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('c8McyYF');
} else {
    $response = \Livewire\Livewire::mount('footer');
    $html = $response->html();
    $_instance->logRenderedChild('c8McyYF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\Users\revan\Downloads\Laravel (2)\Laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>