<div class="container">
    <section>
        <?php echo $__env->make('livewire.instructor-dash.course-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h2 class="text-center text-2xl font-bold text-gray-700">
            All Exams
        </h2>

        <button wire:click="createExam"
                class="btn btn-sm bg-gray-800 btn-outline ring-1 ring-secondary btn-primary">
            Create Exam
        </button>

        <dialog id="my_modal_newExam" class="modal">
            <div class="modal-box">
                <button
                    class="btn btn-sm ring ring-inset ring-secondary btn-circle btn-ghost absolute right-2 top-2"
                    onclick="my_modal_newExam.close()">✕
                </button>

                <h3 class="font-bold text-lg">New Exam</h3>
                <!-- Create Exam Modal -->
                <form class="flex flex-col" wire:submit.prevent="updateExam">
                    <label for="exam_id">Exam ID</label>
                    <input id="exam_id" class="rounded" type="text"
                           wire:model.defer="newExam.exam_id" placeholder="Exam ID">
                    <label for="course_id">Course ID</label>
                    <select id="course_id" class="rounded" wire:model.defer="newExam.course_id">
                        <?php $__currentLoopData = $courseList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course['id']); ?>"><?php echo e($course['course_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="professor_id">Professor ID</label>
                    <select id="professor_id" class="rounded" wire:model.defer="newExam.professor_id">
                        <?php $__currentLoopData = $professorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($professor->id); ?>"><?php echo e($professor->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="time">Time</label>
                    <input id="time" class="rounded" type="datetime-local"
                           wire:model.defer="newExam.time" placeholder="Time">
                    <label for="date">Date</label>
                    <input id="date" class="rounded" type="date"
                           wire:model.defer="newExam.date" placeholder="Date">
                    <button class="btn mt-3 ring ring-secondary" type="submit">Save Exam</button>
                </form>

            </div>
            <form method="dialog" class="modal-backdrop">
                <button>close</button>
            </form>
        </dialog>

        <div class="exams grid grid-cols-1 gap2-">
            <?php if(!empty($examList)): ?>
                <div class="grid grid-cols-1 gap-4 my-4 md:grid-cols-2 lg:grid-cols-3">
                    <?php $__currentLoopData = $examList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $course = App\Models\Course::where('id', $exam->course_id)->first();
                            $professor = App\Models\Instructor::where('id', $exam->professor_id)->first();
                        ?>
                        <div class="exam card bg-white shadow-sm rounded">
                            <div class="exam__content p-3 text-secondary">
                                <h1 class="exam__title"><?php echo e($exam->exam_id); ?></h1>
                                <p class="exam__description"><?php echo e($course->course_name); ?></p>
                                <p class="exam__description"><?php echo e($professor->name); ?></p>
                                <div class="course__actions">
                                    <button wire:click="editExam(<?php echo e($exam->id); ?>)"
                                            class="btn btn-sm bg-gray-800 btn-outline ring-1 ring-secondary btn-primary">
                                        Edit
                                    </button>
                                    <dialog id="edit_modal_<?php echo e($exam->id); ?>" class="modal">
                                        <div class="modal-box">
                                            <button
                                                class="btn btn-sm ring ring-inset ring-secondary btn-circle btn-ghost absolute right-2 top-2"
                                                onclick="edit_modal_<?php echo e($exam->id); ?>.close()">✕
                                            </button>

                                            <h3 class="font-bold text-lg">Edit <?php echo e($exam->exam_id); ?></h3>
                                            <!-- Edit Exam Modal -->
                                            <form class="flex flex-col" wire:submit.prevent="updateExam">
                                                <label for="exam_id">Exam ID</label>
                                                <input id="exam_id" class="rounded" type="text"
                                                       wire:model.defer="selectedExam.exam_id" placeholder="Exam ID">
                                                <label for="course_id">Course ID</label>
                                                <input id="course_id" class="rounded" type="text"
                                                       wire:model.defer="selectedExam.course_id" placeholder="Course ID">
                                                <label for="professor_id">Professor ID</label>
                                                <input id="professor_id" class="rounded" type="text"
                                                       wire:model.defer="selectedExam.professor_id" placeholder="Professor ID">
                                                <label for="time">Time</label>
                                                <input id="time" class="rounded" type="datetime-local"
                                                       wire:model.defer="selectedExam.time" placeholder="Time">
                                                <label for="date">Date</label>
                                                <input id="date" class="rounded" type="date"
                                                       wire:model.defer="selectedExam.date" placeholder="Date">
                                                <button class="btn mt-3 ring ring-secondary" type="submit">Save Exam</button>
                                            </form>

                                        </div>
                                        <form method="dialog" class="modal-backdrop">
                                            <button>close</button>
                                        </form>
                                    </dialog>

                                    <a onclick="my_modal_<?php echo e($exam->exam_id); ?>.showModal()"
                                       class="btn btn-sm btn-outline ring-1 ring-secondary btn-secondary">
                                        Show
                                    </a>
                                    <?php echo $__env->make('livewire.instructor-dash.view-exam', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="text-center">
                    <h1 class="text-2xl font-bold text-gray-700">No exams yet</h1>
                </div>
            <?php endif; ?>

            <script>
                document.addEventListener('DOMContentLoaded', () => {
                    // Listen for the 'openModal' event
                    window.addEventListener('openModal', event => {
                        const modalId = event.detail.id;
                        const modal = document.getElementById(`my_modal_${modalId}`);
                        if (modal) {
                            modal.showModal();
                        }
                    });

                    //openExamModal
                    window.addEventListener('openExamModal', event => {
                        let modalId = event.detail.id;
                        let modalName = `${modalId}`;
                        const modal = document.getElementById(modalName);
                        if (modal) {
                            console.log(modalName);
                            modal.showModal();
                        }else{
                            console.log(modalName, 'not found');
                        }
                    });

                    //closeAllModals
                    window.addEventListener('closeAllModals', event => {
                        //reload the page
                        location.reload();
                    });

                    // Listen for the 'closeModal' event
                    window.addEventListener('closeModal', event => {
                        const modalId = event.detail.id;
                        const modal = document.getElementById(`my_modal_${modalId}`);
                        if (modal) {
                            modal.close();
                            //reload the page
                            location.reload();
                        }
                    });
                });
            </script>

        </div>
    </section>
</div>
<?php /**PATH C:\Users\shano\Downloads\Laravel\resources\views/livewire/instructor-dashboard.blade.php ENDPATH**/ ?>