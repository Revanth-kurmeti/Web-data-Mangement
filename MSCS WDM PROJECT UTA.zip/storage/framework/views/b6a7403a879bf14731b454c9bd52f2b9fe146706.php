<div class="course card bg-white shadow-sm rounded">
    <div class="course__content p-3 text-secondary">
        <h1 class="course__title"><?php echo e($course['course_id']); ?></h1>
        <p class="course__description"><?php echo e($course['course_name']); ?></p>
        <div class="course__actions">

            <button wire:click="editCourse(<?php echo e($course['id']); ?>)"
                    class="btn btn-sm bg-gray-800 btn-outline ring-1 ring-secondary btn-primary">
                Edit
            </button>
            <dialog id="my_modal_<?php echo e($course['id']); ?>" class="modal">
                <div class="modal-box">
                    <button
                        class="btn btn-sm ring ring-inset ring-secondary btn-circle btn-ghost absolute right-2 top-2"
                        onclick="my_modal_<?php echo e($course['id']); ?>.close()">✕
                    </button>

                    <h3 class="font-bold text-lg">Edit <?php echo e($course['course_id']); ?></h3>
                    <form class="flex flex-col" wire:submit.prevent="updateCourse">
                        <label for="course_name">Name</label>
                        <input id="course_name" class="rounded" type="text"
                               wire:model.defer="selectedCourse.course_name" placeholder="Name">
                        <label for="section">Section</label>
                        <input id="section" class="rounded" type="text"
                               wire:model.defer="selectedCourse.section" placeholder="Section">
                        <label for="mode">Mode</label>
                        <input id="mode" class="rounded" type="text"
                               wire:model.defer="selectedCourse.mode" placeholder="Mode">
                        <button class="btn mt-3 ring ring-secondary" type="submit">Save Course</button>
                    </form>

                </div>
                <form method="dialog" class="modal-backdrop">
                    <button>close</button>
                </form>
            </dialog>

            <a onclick="my_modal_<?php echo e($course['course_id']); ?>.showModal()"
               class="btn btn-sm btn-outline ring-1 ring-secondary btn-secondary">
                Show
            </a>
            <dialog id="my_modal_<?php echo e($course['course_id']); ?>" class="modal">
                <div class="modal-box">
                    <button
                        class="btn btn-sm ring ring-inset ring-secondary btn-circle btn-ghost absolute right-2 top-2"
                        onclick="my_modal_<?php echo e($course['course_id']); ?>.close()">✕
                    </button>

                    <h3 class="font-bold text-lg">Show <?php echo e($course['course_id']); ?></h3>
                    <p class="py-4">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Course ID</th>
                            <th>Course Name</th>
                            <th>Section</th>
                            <th>Mode</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td><?php echo e($course['course_id']); ?></td>
                            <td><?php echo e($course['course_name']); ?></td>
                            <td><?php echo e($course['section']); ?></td>
                            <td><?php echo e($course['mode']); ?></td>
                        </tr>
                        </tbody>
                    </table>
                    </p>
                </div>
                <form method="dialog" class="modal-backdrop">
                    <button>close</button>
                </form>
            </dialog>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/livewire/course-card.blade.php ENDPATH**/ ?>