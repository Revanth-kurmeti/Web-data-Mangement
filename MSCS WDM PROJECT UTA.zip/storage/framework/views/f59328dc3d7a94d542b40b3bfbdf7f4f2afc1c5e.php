<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xs text-gray-800 leading-tight">
            Quality Assurance/Dashboard
        </h2>
     <?php $__env->endSlot(); ?>

    <h2 class="text-center">Exams</h2>
    <div class="flex flex-col gap-4 items-center justify-center">
        <?php $__currentLoopData = $examData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examId => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <h4>Exam: <?php echo e($examId); ?></h4>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h2 class="text-center">Exam Results</h2>


    <div class="p-3">
        <canvas id="averageChart"></canvas>
    </div>

    <script>
        const averageCtx = document.getElementById('averageChart').getContext('2d');
        const averageData = <?php echo json_encode($examAverages, 15, 512) ?>;

        const averageChart = new Chart(averageCtx, {
            type: 'bar',
            data: {
                labels: Object.keys(averageData),
                datasets: [{
                    label: 'Average Grade',
                    data: Object.values(averageData),
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/qa/dashboard.blade.php ENDPATH**/ ?>