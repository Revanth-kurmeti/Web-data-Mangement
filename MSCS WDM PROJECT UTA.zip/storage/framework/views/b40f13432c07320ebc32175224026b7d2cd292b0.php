<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xs text-gray-800 leading-tight">
            Instructor/Dashboard
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="courses p-4">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-course', [])->html();
} elseif ($_instance->childHasBeenRendered(time())) {
    $componentId = $_instance->getRenderedChildComponentId(time());
    $componentTag = $_instance->getRenderedChildComponentTagName(time());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(time());
} else {
    $response = \Livewire\Livewire::mount('create-course', []);
    $html = $response->html();
    $_instance->logRenderedChild(time(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('instructor-dashboard', [])->html();
} elseif ($_instance->childHasBeenRendered(time()*2)) {
    $componentId = $_instance->getRenderedChildComponentId(time()*2);
    $componentTag = $_instance->getRenderedChildComponentTagName(time()*2);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(time()*2);
} else {
    $response = \Livewire\Livewire::mount('instructor-dashboard', []);
    $html = $response->html();
    $_instance->logRenderedChild(time()*2, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('results-component', [])->html();
} elseif ($_instance->childHasBeenRendered(time()*3)) {
    $componentId = $_instance->getRenderedChildComponentId(time()*3);
    $componentTag = $_instance->getRenderedChildComponentTagName(time()*3);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(time()*3);
} else {
    $response = \Livewire\Livewire::mount('results-component', []);
    $html = $response->html();
    $_instance->logRenderedChild(time()*3, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/instructor/dashboard.blade.php ENDPATH**/ ?>