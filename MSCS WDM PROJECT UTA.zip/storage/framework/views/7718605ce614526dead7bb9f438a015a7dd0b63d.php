<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
    data-theme="mytheme">

<head>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="antialiased">

    <div class="navbar flex justify-between bg-white shadow-sm">
        <a class="">
            <img width='60px' src="https://upload.wikimedia.org/wikipedia/commons/d/da/UTA_logomark.png" alt="logo" />
        </a>

        <?php if(Route::has('login')): ?>
            <div class="py-4 sm:block">

                <a class="mx-3 text-secondary font-semibold hover:underline "
                    href="https://axm0099.uta.cloud/blog/">Blog</a>

                <?php if(auth()->guard()->check()): ?>
                    <?php
                        $role = Auth::user()->role;
                    ?>
                    <a href="<?php echo e(url($role . '/dashboard')); ?>"
                        class="btn btn-secondary text-quaternary border-quaternary border-2 btn-outline ml-4 text-sm">Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"
                        class="btn btn-secondary text-sm bg-secondary text-white hover:ring-2 ring-secondary">Log in</a>

                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>"
                            class="btn btn-secondary text-quaternary border-quaternary border-2 btn-outline ml-4 text-sm">Join
                            Now</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="relative flex flex-col bg-primary items-top justify-center min-h-screen sm:items-center py-4 sm:pt-0">


        <div class="show-case flex flex-col p-3 sm:p-5 gap-5 bg-secondary">
            <div class="show-case-content">
                <h1 class=" text-3xl sm:text-5xl font-bold">MSC Academic Program</h1>
                <a href={"http://axm0099.uta.cloud/blog/"}>
                </a>
            </div>
            <section id="overview" className="main-section overview">
                <div class="overview-content">
                    <h2 class="text-2xl sm:text-3xl text-center mb-3 font-bold">Overview</h2>
                    <p>

                        The MSC Academic Program in Computer Science is curated with the modern industry's demands in
                        mind. It covers a broad spectrum of subjects ranging from Algorithms, Machine Learning, Cloud
                        Computing to Quantum Computing. Our curriculum ensures that students not only understand the
                        foundational concepts but also get hands-on experience through projects and internships.
                    </p>
                </div>
            </section>
        </div>

        <section class="main-section p-3 sm:p-5 gap-5 bg-quaternary overview">
            <h2 class="text-2xl sm:text-3xl text-center mb-3 font-bold">Objectives</h2>
            <ul>
                <li>To offer a curriculum in line with the latest industry trends and research.</li>
                <li>To provide students with opportunities for hands-on experience and real-world applications.</li>
                <li>To foster a culture of continuous learning and innovation.</li>
                <li>To prepare students for leadership roles in the tech industry and academia.</li>
            </ul>
        </section>


    </div>
</body>

</html>
<?php /**PATH C:\Users\shano\Downloads\Laravel\resources\views/welcome.blade.php ENDPATH**/ ?>