<div class="text-5xl text-white font-bold">
    MSC
</div>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>