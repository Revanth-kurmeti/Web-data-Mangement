<dialog id="my_modal_<?php echo e($exam->exam_id); ?>" class="modal">
    <div class="modal-box">
        <button
            class="btn btn-sm ring ring-inset ring-secondary btn-circle btn-ghost absolute right-2 top-2"
            onclick="my_modal_<?php echo e($exam->exam_id); ?>.close()">✕
        </button>

        <h3 class="font-bold text-lg">Show <?php echo e($exam->exam_id); ?></h3>
        <table class="table">
            <thead>
            <tr>
                <th>Exam ID</th>
                <th>Course ID</th>
                <th>Professor ID</th>
                <th>Time</th>
                <th>Date</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><?php echo e($exam->exam_id); ?></td>
                <td><?php echo e($course->course_id); ?></td>
                <td><?php echo e($professor->name); ?></td>
                <td><?php echo e($exam->time); ?></td>
                <td><?php echo e($exam->date); ?></td>
            </tr>
            </tbody>
        </table>
    </div>
    <form method="dialog" class="modal-backdrop">
        <button>close</button>
    </form>
</dialog>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/livewire/instructor-dash/view-exam.blade.php ENDPATH**/ ?>