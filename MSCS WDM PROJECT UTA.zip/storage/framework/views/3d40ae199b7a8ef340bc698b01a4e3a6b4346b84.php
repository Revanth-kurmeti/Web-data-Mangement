<div x-data="{ isOpen: <?php if ((object) ('isOpen') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('isOpen'->value()); ?>')<?php echo e('isOpen'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('isOpen'); ?>')<?php endif; ?> }" class="fixed bottom-4 right-1 sm:right-4 z-50">
    <button @click="isOpen = !isOpen" class="<?php echo e($isOpen ? 'bg-white text-secondary' : 'bg-blue-500 hover:bg-blue-700 text-white'); ?> ring ring-secondary font-bold py-2 px-4 rounded-full">
        <?php echo e($isOpen ? 'Close' : 'Open'); ?> Chat
    </button>

    <div x-show="isOpen" class="bg-white w-96 h-96 border border-gray-300 rounded-lg shadow-lg overflow-hidden mt-2">
        <div class="flex h-full">
            <!-- User List -->
            <div class="w-1/3 border-r border-gray-300 overflow-y-auto">
                <div class="text-center text-xs">
                    Existing Chats
                </div>
                <!--remove the current user from the list-->
                <?php
                    $usersWithoutCurr = $users->filter(function ($user) {
                        return $user->id !== Auth::id();
                    });
                ?>
                <?php $__currentLoopData = $usersWithoutCurr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button wire:click="selectUser(<?php echo e($user->id); ?>)" class="relative flex gap-2 border my-1 bg-blue-200 items-center w-full text-left p-2 hover:bg-gray-100">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><path d="M406.5 399.6C387.4 352.9 341.5 320 288 320H224c-53.5 0-99.4 32.9-118.5 79.6C69.9 362.2 48 311.7 48 256C48 141.1 141.1 48 256 48s208 93.1 208 208c0 55.7-21.9 106.2-57.5 143.6zm-40.1 32.7C334.4 452.4 296.6 464 256 464s-78.4-11.6-110.5-31.7c7.3-36.7 39.7-64.3 78.5-64.3h64c38.8 0 71.2 27.6 78.5 64.3zM256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zm0-272a40 40 0 1 1 0-80 40 40 0 1 1 0 80zm-88-40a88 88 0 1 0 176 0 88 88 0 1 0 -176 0z"/></svg> <?php echo e($user->name); ?>


                        <p class="text-[8px] absolute top-0 right-0 bg-blue-500 text-white px-1">
                            <?php echo e($user->role); ?>

                        </p>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="rest .">
                    <div class="text-center text-xs">
                        Other Users
                    </div>
                    <?php $__currentLoopData = $restOfUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button wire:click="selectUser(<?php echo e($user->id); ?>)" class="relative flex gap-1 border w-full text-left p-2 hover:bg-gray-100">
                            <svg class="text-secondary" xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><path d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z"/></svg>
                            <?php echo e($user->name); ?>

                            <p class="text-[8px] absolute top-0 right-0 bg-blue-700 text-white px-1">
                                <?php echo e($user->role); ?>

                            </p>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Chat Area -->
            <div class="flex-1 flex flex-col">
                <!-- Chat Header -->
                <div class="bg-gray-100 p-2">
                    <h3 class="text-sm font-semibold">
                        <?php echo e($selectedUserName ?? 'Select a user to chat with'); ?>

                </div>

                <!-- Chat Body -->
                <div class="flex-1 custom-chat overflow-y-auto p-4" wire:poll.5000ms="loadMessages">
                    <?php $__currentLoopData = collect($messages)->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="<?php echo e($message->from === Auth::id() ? 'text-right' : 'text-left'); ?>">
                                <div class="<?php echo e($message->from === Auth::id() ? 'ring-1 ring-inset' : ''); ?> inline-block bg-gray-200 text-sm rounded-t-lg rounded-r-lg px-2 py-1 my-1">
                                    <?php echo e($message->message); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                <!-- Message Input -->
                <?php if($selectedUserId): ?>
                    <div class="p-4 relative">
                        <input type="text" wire:model="messageText" wire:keydown="userTyping" class="border border-gray-300 rounded-full w-full px-4 py-2 text-sm" placeholder="Type a message...">
                        <button wire:click="sendMessage" class="absolute right-[18px] mt-[3px] bg-blue-500 hover:bg-blue-700 text-white font-bold btn btn-circle btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><path d="M498.1 5.6c10.1 7 15.4 19.1 13.5 31.2l-64 416c-1.5 9.7-7.4 18.2-16 23s-18.9 5.4-28 1.6L284 427.7l-68.5 74.1c-8.9 9.7-22.9 12.9-35.2 8.1S160 493.2 160 480V396.4c0-4 1.5-7.8 4.2-10.7L331.8 202.8c5.8-6.3 5.6-16-.4-22s-15.7-6.4-22-.7L106 360.8 17.7 316.6C7.1 311.3 .3 300.7 0 288.9s5.9-22.8 16.1-28.7l448-256c10.7-6.1 23.9-5.5 34 1.4z"/></svg>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/livewire/chatbot.blade.php ENDPATH**/ ?>