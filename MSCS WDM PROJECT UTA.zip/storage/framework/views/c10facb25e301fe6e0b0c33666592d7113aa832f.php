<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xs text-gray-800 leading-tight">
            Student Dashboard
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="bg-svg py-16 px-3 sm:px-4 text-white">
        <h3>
            Hello <?php echo e(auth()->user()->name); ?> welcome to the
            </h3>

            <div class="text-5xl text-white font-bold">
                MSC Academic Program
            </div>
Here you can find all the information about the courses in the MSC Academic Program.
    </div>

    <!-- Courses Section -->
    <div class="p-4">
        <h2 class="text-xl font-bold mb-4">My Courses</h2>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student-courses', [])->html();
} elseif ($_instance->childHasBeenRendered('7mi2IgR')) {
    $componentId = $_instance->getRenderedChildComponentId('7mi2IgR');
    $componentTag = $_instance->getRenderedChildComponentTagName('7mi2IgR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7mi2IgR');
} else {
    $response = \Livewire\Livewire::mount('student-courses', []);
    $html = $response->html();
    $_instance->logRenderedChild('7mi2IgR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <h2 class="text-xl font-bold my-4">All Courses</h2>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('all-courses', [])->html();
} elseif ($_instance->childHasBeenRendered('JmCXXeS')) {
    $componentId = $_instance->getRenderedChildComponentId('JmCXXeS');
    $componentTag = $_instance->getRenderedChildComponentTagName('JmCXXeS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JmCXXeS');
} else {
    $response = \Livewire\Livewire::mount('all-courses', []);
    $html = $response->html();
    $_instance->logRenderedChild('JmCXXeS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/student/dashboard.blade.php ENDPATH**/ ?>