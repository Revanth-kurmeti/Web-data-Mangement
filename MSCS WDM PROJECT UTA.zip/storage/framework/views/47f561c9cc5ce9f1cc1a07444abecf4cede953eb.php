<div>
    <h1 class="text-center text-lg sm:text-3xl text-secondary my-2">Manage Permissions</h1>
    <?php if($usersData->isEmpty()): ?>
        <p>No users found.</p>
    <?php else: ?>
        <!-- Table of Users -->
        <div class="overflow-x-auto">
            <!-- Error Message -->
            <?php if(session()->has('error')): ?>
                <div class="alert alert-error">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <table class="min-w-full table leading-normal">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Net ID</th>
                    <th>Permissions</th>
                    <th>Edit</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $usersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->net_id); ?></td>
                        <td><?php echo e($this->getPermissionsFromRole($user->role)); ?></td>
                        <td>
                            <!-- Open the modal -->
                            <button class="btn btn-primary ring ring-inset ring-secondary" wire:click="editUser(<?php echo e($user->id); ?>)">
                                Edit
                            </button>
                            <dialog id="my_modal_<?php echo e($user->id); ?>" class="modal">
                                <div class="modal-box">
                                    <button class="btn btn-sm ring ring-inset ring-secondary btn-circle btn-ghost absolute right-2 top-2" onclick="my_modal_<?php echo e($user->id); ?>.close()">✕</button>
                                    <h3 class="font-bold text-lg">Edit <?php echo e($user->name); ?></h3>

                                    <form class="flex flex-col gap-2" wire:submit.prevent="updateUser">
                                        <label for="name">Name</label>
                                        <input class="rounded" id="name" type="text" wire:model.defer="selectedUser.name" placeholder="Name">
                                        <label for="email">Email</label>
                                        <input class="rounded" id="email" type="text" wire:model.defer="selectedUser.email" placeholder="Email">
                                        <label for="net_id">Net ID</label>
                                        <input class="rounded" id="net_id" type="text" wire:model.defer="selectedUser.net_id" placeholder="Net ID">

                                        <!-- Role Dropdown -->
                                        <label for="role">Account Permissions</label>
                                        <select class="rounded" id="role" wire:model.defer="selectedUser.role">
                                            <option value=""> -- select an account type --</option>
                                            <option value="student"><?php echo e($this->getPermissionsFromRole('student')); ?></option>
                                            <option value="instructor"><?php echo e($this->getPermissionsFromRole('instructor')); ?></option>
                                            <option value="admin"><?php echo e($this->getPermissionsFromRole('admin')); ?></option>
                                            <option value="qa_officer"><?php echo e($this->getPermissionsFromRole('qa_officer')); ?></option>
                                            <option value="program_coordinator"><?php echo e($this->getPermissionsFromRole('program_coordinator')); ?></option>
                                        </select>

                                        <button class="btn ring ring-secondary mt-2" type="submit">
                                            Save User
                                        </button>
                                    </form>

                                </div>
                                <form method="dialog" class="modal-backdrop">
                                    <button id="close<?php echo e($user->id); ?>" type="button" onclick="my_modal_<?php echo e($user->id); ?>.close()">Cancel</button>
                                </form>
                            </dialog>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <!-- Selected User Details -->
    <?php if($selectedUser): ?>
        <div class="selected-user-details">
            <h3>Selected User:</h3>
            <p>Name: <?php echo e($selectedUser->name); ?></p>
            <p>Email: <?php echo e($selectedUser->email); ?></p>
            <!-- Add more details as needed -->
        </div>
    <?php endif; ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            window.addEventListener('openModal', event => {
                const modalId = event.detail.id;
                document.getElementById(`my_modal_${modalId}`).showModal();
            });
            window.addEventListener('closeModal', event => {
                const modalId = event.detail.id;
                document.getElementById(`my_modal_${modalId}`).close();
                // refresh the page
                window.location.reload();
            });
        });
    </script>

</div>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/livewire/manage-permissions.blade.php ENDPATH**/ ?>