<div class="p-2 py-4 sm:py-8">
    <button class="btn ring btn-primary" wire:click="create">Create New Policy</button>

    
    <?php if($policies->isEmpty()): ?>
        <p class="text-center">No policies found.</p>
    <?php else: ?>
        <table class="table">
            <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Coverage Amount</th>
                <th>Expiry Date</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($policy->name); ?></td>
                    <td><?php echo e($policy->description); ?></td>
                    <td><?php echo e($policy->coverage_amount); ?></td>
                    <td><?php echo e($policy->expiry_date); ?></td>
                    <td class="flex gap-2">
                        <button class="btn btn-secondary btn-sm btn-outline" wire:click="edit(<?php echo e($policy->id); ?>)">Edit</button>
                        <button class="btn btn-danger bg-red-600 btn-sm btn-outline" wire:click="delete(<?php echo e($policy->id); ?>)">Delete</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    
    <dialog id="modalCreate" class="modal">
        <div class="modal-box w-[900px]">
            <button class="close close btn btn-sm btn-circle ring ring-secondary"
                    onClick="document.getElementById('modalCreate').close()"
            >&times;
            </button>
            <form class="space-y-4" wire:submit.prevent="store">
                <h3 class="text-lg font-semibold">Create New Policy</h3>

                <div>
                    <label for="create_name" class="block text-sm font-medium text-gray-700">Name</label>
                    <input id="create_name" type="text" wire:model.defer="name"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                </div>

                <div>
                    <label for="create_description" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea id="create_description" wire:model.defer="description"
                              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"></textarea>
                </div>

                <div>
                    <label for="create_coverage_amount" class="block text-sm font-medium text-gray-700">Coverage
                        Amount</label>
                    <input id="create_coverage_amount" type="number" wire:model.defer="coverage_amount"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                </div>

                <div>
                    <label for="create_expiry_date" class="block text-sm font-medium text-gray-700">Expiry Date</label>
                    <input id="create_expiry_date" type="date" wire:model.defer="expiry_date"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="btn btn-secondary btn-outline mt-2 w-full">Create Policy</button>
                </div>
            </form>
        </div>

    </dialog>


    
    <dialog id="modalUpdate" class="modal">
        <div class="modal-box w-[900px]">
            <button class="close btn btn-sm btn-circle ring ring-secondary"
                    onClick="document.getElementById('modalUpdate').close()"
            >&times;
            </button>

            <form class="space-y-4" wire:submit.prevent="update">
                <h3 class="text-lg font-semibold">Update Policy</h3>

                <div>
                    <label for="update_name" class="block text-sm font-medium text-gray-700">Name</label>
                    <input id="update_name" type="text" wire:model.defer="name"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                </div>

                <div>
                    <label for="update_description" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea id="update_description" wire:model.defer="description"
                              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"></textarea>
                </div>

                <div>
                    <label for="update_coverage_amount" class="block text-sm font-medium text-gray-700">Coverage
                        Amount</label>
                    <input id="update_coverage_amount" type="number" wire:model.defer="coverage_amount"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                </div>

                <div>
                    <label for="update_expiry_date" class="block text-sm font-medium text-gray-700">Expiry Date</label>
                    <input id="update_expiry_date" type="date" wire:model.defer="expiry_date"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="btn btn-primary">Update Policy</button>
                </div>
            </form>
        </div>
    </dialog>


    <script>
        window.addEventListener('openModal', event => {
            document.getElementById(event.detail.id).showModal();
        });

        window.addEventListener('closeModal', event => {
            document.getElementById(event.detail.id).close();
        });
    </script>

</div>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/livewire/policy-manager.blade.php ENDPATH**/ ?>