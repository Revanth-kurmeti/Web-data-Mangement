<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-theme="mytheme">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet"/>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</head>
<body class="font-sans antialiased">
<div class="pt-16 mb-4 bg-gray-100">

    <?php if(Auth::check()): ?>
        <!-- Check if user is authenticated -->
        <?php
            $role = Auth::user()->role; // Assuming you have a 'role' attribute on your User model
        ?>

        <?php if($role === 'instructor'): ?>
            <?php echo $__env->make('layouts.navbar', [
                'dropdownLinks' => [
                    'Dashboard' => route('instructor.dashboard'),
                    'Performance' => route('instructor.performance'),
                    'Profile' => route('profile.edit'),
                    'Help' => route('help'),
                    'Logout' => route('logout')
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($role === 'admin'): ?>
            <?php echo $__env->make('layouts.navbar', [
                'dropdownLinks' => [
                    'Dashboard' => route('admin.dashboard'),
                    'Profiles' => route('admin.profiles'),
                    'Permissions' => route('admin.permissions'),
                    'Courses' => route('admin.courses'),
                    'Profile' => route('profile.edit'),
                    'Help' => route('help'),
                    'Logout' => route('logout')
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($role === 'student'): ?>
            <?php echo $__env->make('layouts.navbar', [
                'dropdownLinks' => [
                    'Dashboard' => route('student.dashboard'),
                    'Courses' => route('student.courses'),
                    'Profile' => route('profile.edit'),
                    'Help' => route('help'),
                    'Logout' => route('logout')
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($role ==='program_coordinator'): ?>
            <?php echo $__env->make('layouts.navbar', [
                'dropdownLinks' => [
                    'Dashboard' => route('program_coordinator.dashboard'),
                    'Performance' => route('program_coordinator.performance'),
                    'Profile' => route('profile.edit'),
                    'Help' => route('help'),
                    'Logout' => route('logout')
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php elseif($role ==='qa_officer'): ?>
            <?php echo $__env->make('layouts.navbar', [
                'dropdownLinks' => [
                    'Dashboard' => route('qa_officer.dashboard'),
                    'Policies' => route('qa_officer.policies'),
                    'Assessments' => route('qa_officer.assessments'),
                    'Profile' => route('profile.edit'),
                    'Help' => route('help'),
                    'Logout' => route('logout')
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Page Heading -->
    <?php if(isset($header)): ?>
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-2 py-2 text-sm">
                <?php echo e($header); ?>

            </div>
        </header>
    <?php endif; ?>

    <!-- Page Content -->
    <main class="flex-1 overflow-y-auto focus:outline-none">
        <?php echo e($slot); ?>

    </main>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chatbot', [])->html();
} elseif ($_instance->childHasBeenRendered('jLAjlLi')) {
    $componentId = $_instance->getRenderedChildComponentId('jLAjlLi');
    $componentTag = $_instance->getRenderedChildComponentTagName('jLAjlLi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jLAjlLi');
} else {
    $response = \Livewire\Livewire::mount('chatbot', []);
    $html = $response->html();
    $_instance->logRenderedChild('jLAjlLi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</body>
</html>
<?php /**PATH C:\Users\shano\Downloads\Laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>