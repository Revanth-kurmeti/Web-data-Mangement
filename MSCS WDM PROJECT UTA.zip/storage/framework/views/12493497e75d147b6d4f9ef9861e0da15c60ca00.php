<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('layouts.navbar', [
        'dropdownLinks' => [
            'Profile' => route('profile.edit'),
            'Help' => route('help'),
            'Profiles' => route('admin.profiles'),
            'Permissions' => route('admin.permissions'),
            'Dashboard' => route('admin.dashboard'),
            'Courses'=> route('admin.courses'),
            'Logout' => route('logout')
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xs text-gray-800 leading-tight">
            Admin/Dashboard
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="flex flex-col items-center p-2 justify-center w-full h-full">
        <h1 class="font-bold mb-4">Dashboard</h1>

        <!-- Charts Section -->
        <div class="grid grid-cols-1 sm:grid-cols-2 p-4 items-center gap-2 -mx-2">
            <div class="w-full px-2 mb-4">
                <div class="bg-white p-6 rounded-lg shadow">
                    <h2 class="font-bold mb-2">User Registrations Over Time</h2>
                    <canvas id="lineChart"></canvas>
                </div>
            </div>

            <div class="w-full px-2 mb-4">
                <div class="bg-white p-6 rounded-lg shadow">
                    <h2 class="font-bold mb-2">Queries Over Time</h2>
                    <canvas id="barChart"></canvas>
                </div>
            </div>

            <div class="w-full max-h-96 overflow-hidden px-2 mb-4">
                <div class="bg-white p-6 rounded-lg shadow">
                    <h2 class="font-bold mb-2">Grade Distribution</h2>
                    <canvas class="max-h-[16rem]" id="gradeDistributionChart"></canvas>
                </div>
            </div>

        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const usersData = <?php echo json_encode($usersData, 15, 512) ?>;
            const queriesData = <?php echo json_encode($queriesData, 15, 512) ?>;

            // Line Chart - User Registrations
            const ctxLine = document.getElementById('lineChart').getContext('2d');
            const lineChart = new Chart(ctxLine, {
                type: 'line',
                data: {
                    labels: usersData.map(user => user.name),
                    datasets: [{
                        label: 'User Registrations',
                        data: usersData.map(user => new Date(user.created_at)),
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgb(75, 192, 192)',
                        tension: 0.1
                    }]
                }
            });

            // Bar Chart - Queries
            const ctxBar = document.getElementById('barChart').getContext('2d');
            const barChart = new Chart(ctxBar, {
                type: 'bar',
                data: {
                    labels: queriesData.map(query => query.email),
                    datasets: [{
                        label: 'Queries',
                        data: queriesData.map(query => query.id),
                        backgroundColor: 'rgba(75, 192, 192, 0.2)'
                    }]
                }
            });
        });

        document.addEventListener('DOMContentLoaded', function () {
            const gradeDistribution = JSON.parse(<?php echo json_encode($gradeDistribution, 15, 512) ?>);

            const ctxGradeDistribution = document.getElementById('gradeDistributionChart').getContext('2d');
            const gradeDistributionChart = new Chart(ctxGradeDistribution, {
                type: 'pie',
                data: {
                    labels: Object.keys(gradeDistribution),
                    datasets: [{
                        label: 'Grade Distribution',
                        data: Object.values(gradeDistribution),
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(153, 102, 255, 0.2)',
                            'rgba(255, 159, 64, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>