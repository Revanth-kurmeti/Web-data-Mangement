<nav class="absolute top-0 right-0 navbar flex justify-between align-middle items-center"
     style="background-color: var(--secondary);">
    <span class="w-1/4">
<a class="first-letter:uppercase" href="#">
    <?php echo e(auth()->user()->role == 'program_coordinator' ? 'pc' : auth()->user()->role); ?>

</a>
    </span>

    <?php if(auth()->guard()->check()): ?>
        <center class="w-auto flex items-center justify-center">
            <a href="#">Logged in as <?php echo e(Auth::user()->name); ?></a>
        </center>

        <ul class="w-1/4 flex items-center justify-end">
            <?php $__currentLoopData = $dropdownLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkName => $linkUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="hidden text-sm md:block my-1 py-1 ">
                    <?php if($linkName == 'Logout'): ?>
                        <a class="bg-red-600 p-2 rounded text-white" href="<?php echo e($linkUrl); ?>"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e($linkName); ?></a>
                        <form id="logout-form" action="<?php echo e($linkUrl); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php else: ?>
                        <a class="mx-1 text-secondary hover:bg-gray-50 px-1 py-2 rounded"
                           href="<?php echo e($linkUrl); ?>"><?php echo e($linkName); ?></a>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li class="md:hidden">
                <details class="dropdown dropdown-end">
                    <summary class="m-1 relative">
                        <svg class="absolute top-0 right-0" style="font-size: 35px;" xmlns="http://www.w3.org/2000/svg"
                             height="1em" viewBox="0 0 512 512">
                            <path fill="white"
                                  d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z"/>
                        </svg>
                    </summary>
                    <ul class="p-2 shadow menu gap-4 dropdown-content z-[1] bg-base-100 rounded w-32 ">
                        <?php $__currentLoopData = $dropdownLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkName => $linkUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($linkName == 'Logout'): ?>
                                <a class="bg-red-600 p-2 rounded text-white" href="<?php echo e($linkUrl); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e($linkName); ?></a>
                                <form id="logout-form" action="<?php echo e($linkUrl); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e($linkUrl); ?>"><?php echo e($linkName); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </details>
            </li>
        </ul>
    <?php endif; ?>
</nav>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>