<div>
    <form wire:submit.prevent="save">
        <label for="exam_id">Exam ID</label>
        <input wire:model.defer="exam_id" id="exam_id" type="text" required>

        <label for="course_id">Course ID</label>
        <input wire:model.defer="course_id" id="course_id" type="text" required>

        <label for="professor_id">Professor ID</label>
        <input wire:model.defer="professor_id" id="professor_id" type="text" required>

        <label for="time">Time</label>
        <input wire:model.defer="time" id="time" type="text" required>

        <label for="date">Date</label>
        <input wire:model.defer="date" id="date" type="text" required>

        <button type="submit">Save Exam</button>
    </form>
</div>
<?php /**PATH C:\Freelance\11-15-23\laravel\resources\views/livewire/exam-form.blade.php ENDPATH**/ ?>