<div>
    <?php if($allCourses->isEmpty()): ?>
        <p>No courses available at the moment.</p>
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php $__currentLoopData = $allCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-md shadow-sm p-4">
                    <h3 class="text-lg font-bold"><?php echo e($course->course_name); ?></h3>
                    <p>Course ID: <?php echo e($course->course_id); ?></p>
                    <p>Section: <?php echo e($course->section); ?></p>
                    <p>Mode: <?php echo e($course->mode); ?></p>
                    <?php if($course->enrolled): ?>
                        <button
                            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mt-2"
                            wire:click="unenroll('<?php echo e($course->id); ?>')"
                        >
                            Unenroll
                        </button>
                    <?php else: ?>
                        <button
                            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-2"
                            wire:click="enroll('<?php echo e($course->id); ?>')"
                        >
                            Enroll
                        </button>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\revan\Downloads\laravel updated\laravel\resources\views/livewire/all-courses.blade.php ENDPATH**/ ?>