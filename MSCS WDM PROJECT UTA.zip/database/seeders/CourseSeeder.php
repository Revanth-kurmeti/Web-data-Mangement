<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\Instructor;
use App\Models\Course;

class CourseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $instructors = Instructor::all();

        foreach ($instructors as $instructor) {
            for ($i = 1; $i <= 5; $i++) {
                Course::create([
                    'course_id' => 'CS' . $instructor->id . '0' . $i,
                    'course_name' => "Course $i of Instructor " . $instructor->name,
                    'section' => 'A',
                    'mode' => 'Online',
                    'instructor_id' => $instructor->id,
                ]);
            }
        }
    }
}
