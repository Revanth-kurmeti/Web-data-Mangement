<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\Instructor;

class InstructorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i = 1; $i <= 5; $i++) {
            Instructor::create([
                'instructor_id' => 'instr00' . $i,
                'net_id' => 'net00' . $i,
                'name' => "Instructor $i",
                'email' => "instructor$i@example.com",
                'phone_number' => '123456789' . $i,
                'courses' => json_encode(["CS10$i", "CS20$i"]),
                'password' => Hash::make('password'),
            ]);
        }
    }
}
